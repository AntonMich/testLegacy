import { Component, OnInit } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import 'rxjs/add/operator/toPromise';
import { MessageService } from './message.service';


@Component( {
    selector: 'app-root',
    template: `<label>Введите message:</label>
    
        <input [(ngModel)]="message" placeholder="">
        reverse: {{jjson}}
        <div>
      <button (click)="sendToServer(message)">Send to server</button>
      </div>
      <div>
      <button (click)="_reloadMyData()">Click</button>
        </div>
    <table>
    <th>Count</th><th>Stroka</th>
      <tr *ngFor='let stroka of myStringArray; let i = index'>
          <td>{{i}}</td>
          <td>{{stroka}}</td>
      </tr>
  </table>
        <h1>{{myStringArray.length}}!</h1>`

    //templateUrl: "app/app.component.html"
})

export class AppComponent {

    public myStringArray: Array<string> = [];
    public jjson: string;
    constructor( private http: Http ) {

    }


    sendToServer( mymessage ) {

        var body = "stroka:" + mymessage;
        this.http.post( "http://localhost:8080/testLegacy/start/messageme", body, status )
            .map(( res: Response ) => { return res.text() }).subscribe( data => { mymessage = data });
        this.myStringArray.push(this._reloadMyData());

    }
    private _reloadMyData() {
        var str:string;
        this.http.get( 'http://localhost:8080/testLegacy/start/message' )
            .subscribe(result => this.jjson=result.json());
        return this.jjson;

    }
}
